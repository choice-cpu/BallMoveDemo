using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

public class BallOrbitCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 pivotPoint = Vector3.zero;
    public float minDistance = 3;
    public float maxDistance = 25;
    public float rotateSpeed = 0.25f;
    public float zoomSpeed = 0.01f;

    float yaw, pitch, distance;
    float startYaw, startPitch, startDistance;

    void Start()
    {
        // 从相机现在的位置反推角度，运行时视角就不会跳
        Vector3 offset = transform.position - GetPivot();
        distance = offset.magnitude;
        Vector3 dir = offset / distance;
        pitch = Mathf.Asin(dir.y) * Mathf.Rad2Deg;
        yaw = Mathf.Atan2(-dir.x, -dir.z) * Mathf.Rad2Deg;

        startYaw = yaw;
        startPitch = pitch;
        startDistance = distance;
    }

    void Update()
    {
        Mouse mouse = Mouse.current;
        if (mouse == null) return;

        // 鼠标在 UI 面板上时不要转视角
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()) return;

        if (mouse.leftButton.isPressed || mouse.rightButton.isPressed)
        {
            Vector2 delta = mouse.delta.ReadValue();
            yaw += delta.x * rotateSpeed;
            pitch = Mathf.Clamp(pitch - delta.y * rotateSpeed, -25, 80);
        }

        float scroll = mouse.scroll.ReadValue().y;
        if (scroll != 0)
            distance = Mathf.Clamp(distance - scroll * zoomSpeed, minDistance, maxDistance);

        // 按 R 回到开始的视角
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
        {
            yaw = startYaw;
            pitch = startPitch;
            distance = startDistance;
        }

        Vector3 pivot = GetPivot();
        transform.position = pivot + Quaternion.Euler(pitch, yaw, 0) * Vector3.back * distance;
        transform.LookAt(pivot);
    }

    Vector3 GetPivot()
    {
        return target != null ? target.position : pivotPoint;
    }
}
