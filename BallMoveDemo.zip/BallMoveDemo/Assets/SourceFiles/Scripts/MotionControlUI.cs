using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

public class MotionControlUI : MonoBehaviour
{
    public BallMove mover;

    Font font;

    void Awake()
    {
        if (mover == null) mover = FindFirstObjectByType<BallMove>();
        font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        if (FindFirstObjectByType<EventSystem>() == null)
        {
            GameObject system = new GameObject("EventSystem");
            system.AddComponent<EventSystem>();
            system.AddComponent<InputSystemUIInputModule>().AssignDefaultActions();
        }

        GameObject canvasObject = new GameObject("Canvas");
        canvasObject.AddComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        canvasObject.AddComponent<GraphicRaycaster>();

        GameObject panel = MakeImage("Panel", canvasObject.transform, new Color(0.06f, 0.07f, 0.09f, 0.86f));
        RectTransform panelRect = panel.GetComponent<RectTransform>();
        panelRect.anchoredPosition = new Vector2(32, -32);
        panelRect.sizeDelta = new Vector2(420, 216);

        MakeText(panel.transform, "Ball Motion", 24, new Vector2(24, -18), new Vector2(372, 34));
        MakeSlider(panel.transform, "Speed", 0.5f, 10, mover.speed, -70, mover.SetSpeed);
        MakeSlider(panel.transform, "Wait Time", 0, 2, mover.waitTime, -140, mover.SetWaitTime);
    }

    void MakeSlider(Transform parent, string label, float min, float max, float value, float y, UnityAction<float> onChanged)
    {
        MakeText(parent, label, 19, new Vector2(24, y), new Vector2(260, 26));
        Text number = MakeText(parent, value.ToString("0.00"), 19, new Vector2(280, y), new Vector2(116, 26));
        number.color = new Color(0.55f, 0.82f, 1);

        GameObject sliderObject = new GameObject("Slider");
        sliderObject.transform.SetParent(parent, false);
        RectTransform sliderRect = sliderObject.AddComponent<RectTransform>();
        sliderRect.anchorMin = sliderRect.anchorMax = new Vector2(0, 1);
        sliderRect.pivot = new Vector2(0, 1);
        sliderRect.anchoredPosition = new Vector2(24, y - 30);
        sliderRect.sizeDelta = new Vector2(372, 22);

        GameObject background = MakeImage("Background", sliderRect, new Color(0.2f, 0.22f, 0.27f));
        RectTransform backgroundRect = background.GetComponent<RectTransform>();
        backgroundRect.anchorMin = new Vector2(0, 0.5f);
        backgroundRect.anchorMax = new Vector2(1, 0.5f);
        backgroundRect.sizeDelta = new Vector2(0, 10);

        // 填充条要套一层 Fill Area，否则高度会被拉满
        GameObject fillArea = new GameObject("Fill Area");
        fillArea.transform.SetParent(sliderRect, false);
        RectTransform fillAreaRect = fillArea.AddComponent<RectTransform>();
        fillAreaRect.anchorMin = new Vector2(0, 0.5f);
        fillAreaRect.anchorMax = new Vector2(1, 0.5f);
        fillAreaRect.sizeDelta = new Vector2(-22, 10);

        GameObject fill = MakeImage("Fill", fillAreaRect, new Color(0.35f, 0.75f, 1));
        RectTransform fillRect = fill.GetComponent<RectTransform>();
        fillRect.anchorMax = new Vector2(0, 1);
        fillRect.sizeDelta = new Vector2(10, 0);

        GameObject handleArea = new GameObject("Handle Area");
        handleArea.transform.SetParent(sliderRect, false);
        RectTransform handleAreaRect = handleArea.AddComponent<RectTransform>();
        handleAreaRect.anchorMin = new Vector2(0, 0.5f);
        handleAreaRect.anchorMax = new Vector2(1, 0.5f);
        handleAreaRect.sizeDelta = new Vector2(-22, 0);

        GameObject handle = MakeImage("Handle", handleAreaRect, Color.white);
        RectTransform handleRect = handle.GetComponent<RectTransform>();
        handleRect.anchorMin = new Vector2(0, 0.5f);
        handleRect.anchorMax = new Vector2(0, 0.5f);
        handleRect.sizeDelta = new Vector2(22, 22);

        Image handleImage = handle.GetComponent<Image>();
        handleImage.sprite = Resources.GetBuiltinResource<Sprite>("UI/Skin/Knob.psd");

        Slider slider = sliderObject.AddComponent<Slider>();
        slider.fillRect = fillRect;
        slider.handleRect = handleRect;
        slider.targetGraphic = handleImage;
        slider.minValue = min;
        slider.maxValue = max;
        slider.value = value;

        slider.onValueChanged.AddListener(delegate (float v)
        {
            number.text = v.ToString("0.00");
            onChanged(v);
        });
    }

    Text MakeText(Transform parent, string content, int size, Vector2 position, Vector2 boxSize)
    {
        GameObject textObject = new GameObject("Text");
        textObject.transform.SetParent(parent, false);

        RectTransform rect = textObject.AddComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1);
        rect.anchoredPosition = position;
        rect.sizeDelta = boxSize;

        Text text = textObject.AddComponent<Text>();
        text.text = content;
        text.font = font;
        text.fontSize = size;
        text.color = Color.white;
        text.alignment = TextAnchor.MiddleLeft;
        text.raycastTarget = false;
        return text;
    }

    GameObject MakeImage(string name, Transform parent, Color color)
    {
        GameObject imageObject = new GameObject(name);
        imageObject.transform.SetParent(parent, false);

        RectTransform rect = imageObject.AddComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1);

        Image image = imageObject.AddComponent<Image>();
        image.color = color;
        return imageObject;
    }
}
