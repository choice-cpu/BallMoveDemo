using UnityEngine;

public class BallPingPongMover : MonoBehaviour
{
    public Vector3 pointA = new Vector3(-4, 0, 0);
    public Vector3 pointB = new Vector3(4, 0, 0);

    public float speed = 2.5f;          // 移动速度
    public float waitTime = 0.4f;       // 到端点停多久
    public float curveStrength = 0.7f;  // 两边快中间慢
    public bool startFromA = true;

    float t = 0;        // 0 在 A 点，1 在 B 点
    float waitTimer = 0;
    bool moving = true;
    bool forward = true;

    void Start()
    {
        forward = startFromA;
        t = startFromA ? 0 : 1;
        transform.position = GetPosition(t);
    }

    void Update()
    {
        // 到端点先停一会儿
        if (moving == false)
        {
            waitTimer += Time.deltaTime;
            if (waitTimer >= waitTime)
            {
                waitTimer = 0;
                moving = true;
            }
            return;
        }

        float distance = Vector3.Distance(pointA, pointB);
        float step = Time.deltaTime * speed / distance;
        t += forward ? step : -step;

        if (t >= 1 || t <= 0)
        {
            t = Mathf.Clamp01(t);
            forward = !forward;
            moving = false;
            waitTimer = 0;
        }

        transform.position = GetPosition(t);
    }

    // 加一个 sin，让两头走得快、中间走得慢
    Vector3 GetPosition(float progress)
    {
        float p = progress + curveStrength / (2 * Mathf.PI) * Mathf.Sin(2 * Mathf.PI * progress);
        return Vector3.Lerp(pointA, pointB, p);
    }

    public void SetSpeed(float value) { speed = value; }
    public void SetWaitTime(float value) { waitTime = value; }
}
