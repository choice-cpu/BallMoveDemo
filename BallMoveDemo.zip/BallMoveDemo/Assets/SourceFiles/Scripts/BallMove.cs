using UnityEngine;

public class BallMove : MonoBehaviour
{
    public Vector3 pointA = new Vector3(-4, 0, 0);
    public Vector3 pointB = new Vector3(4, 0, 0);

    public float speed = 2.5f;
    public float waitTime = 0.4f;
    public float curveStrength = 0.7f;
    
    public bool startFromA = true;

    float t = 0;
    float waitTimer = 0;
    bool moving = true;
    bool forward = true;

    void Start()
    {
        forward = startFromA;
        t = startFromA ? 0 : 1;
        transform.position = GetPosition(t);
    }

    void Update()
    {
        if (moving == false)
        {
            waitTimer += Time.deltaTime;
            if (waitTimer >= waitTime)
            {
                waitTimer = 0;
                moving = true;
            }
            return;
        }

        float distance = Vector3.Distance(pointA, pointB);
        float step = Time.deltaTime * speed / distance;
        t += forward ? step : -step;

        if (t >= 1 || t <= 0)
        {
            t = Mathf.Clamp01(t);
            forward = !forward;
            moving = false;
            waitTimer = 0;
        }

        transform.position = GetPosition(t);
    }

    Vector3 GetPosition(float progress)
    {
        float p = progress + curveStrength / (2 * Mathf.PI) * Mathf.Sin(2 * Mathf.PI * progress);
        return Vector3.Lerp(pointA, pointB, p);
    }

    public void SetSpeed(float value) { speed = value; }
    public void SetWaitTime(float value) { waitTime = value; }
}
